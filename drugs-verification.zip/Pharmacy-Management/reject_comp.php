<?php
  require "php/db_connection.php";
  if($con) {
    $id = $_GET["id"];
    //$packing = strtoupper($_GET["packing"]);
    //$generic_name = ucwords($_GET["generic_name"]);
    //$suppliers_name = $_GET["suppliers_name"];

    $sql = "UPDATE companies SET status = '3' WHERE id = '$id'";
    
		if($con->query($sql)){
			$_SESSION['success'] = 'Compony updated successfully
      ';
      //echo $id;
      header('location: compony.php');
		}
		else{
			$_SESSION['error'] = $conn->error;
      header('location: compony.php');
		}
	

	
  }
?>
