<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Pharmacy Management - SETUP</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
		<script src="bootstrap/js/jquery.min.js"></script>
		<script src="bootstrap/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
    <link rel="shortcut icon" href="images/icon.svg" type="image/x-icon">
    <link rel="stylesheet" href="css/index.css">
    <script src="js/validateForm.js"></script>
    <script src="js/index.js"></script>
    <style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: red;
  color: white;
}
</style>
  </head>
  <body style="background-image: url('images/cap.jpg');">
  
<div class="topnav">
  <a class="active" href="register.php">Register</a>
  <a href="#news">News</a>
  <a href="login.php">Login</a>
  <a href="admin.php">Admin</a>
</div>
    <div class="container" style="margin-top:20px">
      <div class="card m-auto p-2">
        <div class="card-body">
          <form name="login-form" class="login-form" action="php/add_new_compony.php" method="post">
            <div class="logo">
              <h1 class="logo-caption font-weight-bolder"><span class="tweak">P</span>harmacy <span class="tweak">M</span>anagement</h1>
        			<h2 class="logo-caption font-weight-bolder"><span class="tweak">O</span>ne <span class="tweak">T</span>ime <span class="tweak">S</span>etup</h2>
              <p class="h5 text-center text-light">Enter necessary pharmacy details<p>
        		</div> <!-- logo class -->

            <div class="input-group form-group">
              <div class="input-group-prepend">
                <span class="input-group-text"><i class="fas fa-plus-square text-white"></i></span>
              </div>
              <input type="text" name="cname" class="form-control" placeholder="compony name" >
            </div> <!--input-group class -->
            <code class="text-light small font-weight-bold float-right mb-2"  style="display: none;"></code>
            
            <div class="input-group form-group">
              <div class="input-group-prepend">
                <span class="input-group-text"><i class="fas fa-plus-square text-white"></i></span>
              </div>
              <input type="text" name="com_id" class="form-control" placeholder="CAC number" >
            </div> <!--input-group class -->
            <code class="text-light small font-weight-bold float-right mb-2"  style="display: none;"></code>
            
            <?php $nafdacid='NAFDAC-'.rand('11111','99999');?>
            <input name="nafdacid" type="hidden" class="form-control" value="<?php echo $nafdacid;?>">
            
            <div class="input-group form-group">
              <div class="input-group-prepend">
                <span class="input-group-text"><i class="fas fa-plus-square text-white"></i></span>
              </div>
              <input name="state" type="text" class="form-control" placeholder="Compony State">
            </div> <!--input-group class -->
            <code class="text-light small font-weight-bold float-right mb-2" id="pharmacy_name_error" style="display: none;"></code>

            <div class="input-group form-group">
              <div class="input-group-prepend">
                <span class="input-group-text"><i class="fas fa-address-card text-white"></i></span>
              </div>
              <textarea name="caddress" class="form-control" placeholder="address"  style="max-height: 100px;" ></textarea>
            </div> <!-- input-group class -->
            <code class="text-light small font-weight-bold float-right mb-2" id="address_error" style="display: none;"></code>

            <div class="input-group form-group">
              <div class="input-group-prepend">
                <span class="input-group-text"><i class="fas fa-envelope text-white"></i></span>
              </div>
              <input name="email" type="email" class="form-control" placeholder="email" >
            </div> <!--input-group class -->
            <code class="text-light small font-weight-bold float-right mb-2" id="email_error" style="display: none;"></code>

            <div class="input-group form-group">
              <div class="input-group-prepend">
                <span class="input-group-text"><i class="fas fa-mobile-alt text-white"></i></span>
              </div>
              <input id="contact_number" name="contact_number" type="number" class="form-control" placeholder="contact number" onkeyup="validateContactNumber(this.value, 'contact_number_error');" >
            </div> <!-- input-group class -->
            <code class="text-light small font-weight-bold float-right mb-2" id="contact_number_error" style="display: none;"></code>
            

            <div class="input-group form-group">
              <div class="input-group-prepend">
                <span class="input-group-text"><i class="fas fa-user text-white"></i></span>
              </div>
              <input name="username" type="text" class="form-control" placeholder="enter username" onblur="notNull(this.value, 'username_error');" >
            </div> <!--input-group class -->
            <code class="text-light small font-weight-bold float-right mb-2" id="username_error" style="display: none;"></code>

            <div class="input-group form-group">
              <div class="input-group-prepend">
                <span class="input-group-text"><i class="fas fa-lock text-white"></i></span>
              </div>
              <input name="password" type="text" class="form-control" placeholder="enter password">
            </div> <!-- input-group class -->
            <code class="text-light small font-weight-bold float-right mb-2" id="password_error" style="display: none;"></code>

            <div class="input-group form-group">
              <div class="input-group-prepend">
                <span class="input-group-text"><i class="fas fa-key text-white"></i></span>
              </div>
              <input id="confirm_password" type="password" class="form-control" placeholder="confirm password">
            </div> <!-- input-group class -->
            <code class="text-light small font-weight-bold float-right mb-2" id="confirm_password_error" style="display: none;"></code>

            <div class="form-group">
              <button class="btn btn-default btn-block btn-custom">START</button>
            </div>
          </form><!-- form close -->
          
          
        </div> <!-- cord-footer class -->
        </div> <!-- cord-body class -->
      </div> <!-- card class -->
    </div> <!-- container class -->
  </body>
</html>
