<?php
  require "db_connection.php";
  if($con) {
    $cname = $_POST["cname"];
    $com_id = $_POST["com_id"];
    $state = $_POST["state"];
    $email = $_POST["email"];
    $username = $_POST["username"];
    $password = $_POST["password"];
    $contact_number = $_POST["contact_number"];
    $caddress = $_POST["caddress"];
    $nafdacid = $_POST["nafdacid"];
    //$doctor_address = $_POST["doctor_address"];

    $query = "SELECT * FROM companies WHERE nafdacid = '$nafdacid' OR com_id='$com_id'";
    $result = mysqli_query($con, $query);
    $row = mysqli_fetch_array($result);
    if($row)
      echo "Compony ".$row['cname']." with id $com_id already exists!";
    else {
      $query = "INSERT INTO companies (cname, state, nafdacid, caddress, com_id) 
      VALUES('$cname', '$state', '$nafdacid', '$caddress', '$com_id')";
      $result = mysqli_query($con, $query);
      if(!empty($result)){

        $query2 = "INSERT INTO customers (CONTACT_NUMBER, ADDRESS, username, password) 
        VALUES('$contact_number', '$caddress', '$username', '$password')";
        $result2 = mysqli_query($con, $query2);
      echo "$cname added...";
      }
  			
  		else{
            echo "Failed to add $cname!";
        }
  			
    }
  }
?>
